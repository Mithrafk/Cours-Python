#%%
import random as rd

TAILLE_CARTE = 100


class Plante:
    def __init__(self, numero, pos):
        self.numero = numero
        self.pos = pos
        self.vivant = True

    def mort(self):
        self.vivant = False


class Herbivore:
    def __init__(self, numero, pos):
        self.numero = numero
        self.pos = pos
        self.nourriture = 5
        self.age = 1
        self.vivant = True

    def deplacement(self, dx, dy):
        x = min(max(self.pos[0] + dx, 0), TAILLE_CARTE - 1)
        y = min(max(self.pos[1] + dy, 0), TAILLE_CARTE - 1)
        self.pos = (x, y)
        self.nourriture -= 0.25

    def mort(self):
        self.vivant = False

    def manger(self, plante):
        if plante.vivant:
            plante.mort()
            self.nourriture += 1.25

    def repro(self):
        if self.nourriture >= 10:
            self.nourriture -= 5
            return Herbivore(f"{self.numero}_enfant", self.pos)
        return None

    def agir(self, plante_list):
        """Fait vivre l'herbivore pendant UN jour. Renvoie un enfant ou None."""
        if self.nourriture <= 0:
            self.mort()
            return None

        self.deplacement(rd.randint(-1, 1), rd.randint(-1, 1))

        for plante in plante_list:
            if plante.vivant and plante.pos == self.pos:
                self.manger(plante)
                break  # une seule plante mangée par jour

        self.age += 1
        return self.repro()


class Carnivore:
    def __init__(self, numero, pos):
        self.numero = numero
        self.pos = pos
        self.nourriture = 5
        self.age = 1
        self.vivant = True

    def deplacement(self, dx, dy):
        x = min(max(self.pos[0] + dx, 0), TAILLE_CARTE - 1)
        y = min(max(self.pos[1] + dy, 0), TAILLE_CARTE - 1)
        self.pos = (x, y)
        self.nourriture -= 0.5

    def mort(self):
        self.vivant = False

    def manger(self, herbivore):
        if herbivore.vivant:
            herbivore.mort()
            self.nourriture += 2.5

    def repro(self):
        if self.nourriture >= 20:
            self.nourriture -= 10
            return Carnivore(f"{self.numero}_enfant", self.pos)
        return None

    def agir(self, herbivore_list):
        """Fait vivre le carnivore pendant UN jour. Renvoie un enfant ou None."""
        if self.nourriture <= 0:
            self.mort()
            return None

        self.deplacement(rd.randint(-1, 1), rd.randint(-1, 1))

        for herbivore in herbivore_list:
            if herbivore.vivant and herbivore.pos == self.pos:
                self.manger(herbivore)
                break  # un seul herbivore mangé par jour

        self.age += 1
        return self.repro()


def initialisation(nplante, nherbivore, ncarnivore):
    plante_list = [
        Plante(f"plante_{i}", (rd.randint(0, TAILLE_CARTE - 1), rd.randint(0, TAILLE_CARTE - 1)))
        for i in range(nplante)
    ]
    herbivore_list = [
        Herbivore(f"herbivore_{i}", (rd.randint(0, TAILLE_CARTE - 1), rd.randint(0, TAILLE_CARTE - 1)))
        for i in range(nherbivore)
    ]
    carnivore_list = [
        Carnivore(f"carnivore_{i}", (rd.randint(0, TAILLE_CARTE - 1), rd.randint(0, TAILLE_CARTE - 1)))
        for i in range(ncarnivore)
    ]
    return plante_list, herbivore_list, carnivore_list


def Simulation(plante_list, herbivore_list, carnivore_list, jour):
    """Fait avancer la simulation d'UN jour, en place sur les listes fournies."""

    nouveaux_herbivores = []
    for herbivore in herbivore_list:
        if herbivore.vivant:
            enfant = herbivore.agir(plante_list)
            if enfant is not None:
                nouveaux_herbivores.append(enfant)

    nouveaux_carnivores = []
    for carnivore in carnivore_list:
        if carnivore.vivant:
            enfant = carnivore.agir(herbivore_list)
            if enfant is not None:
                nouveaux_carnivores.append(enfant)

    # nettoyage des morts + ajout des naissances, en modifiant les listes
    # EN PLACE (via [:]) pour que les références déjà tenues ailleurs
    # (ex: le script d'animation) restent valides
    plante_list[:] = [p for p in plante_list if p.vivant]
    herbivore_list[:] = [h for h in herbivore_list if h.vivant] + nouveaux_herbivores
    carnivore_list[:] = [c for c in carnivore_list if c.vivant] + nouveaux_carnivores


def main():
    plante_list, herbivore_list, carnivore_list = initialisation(100, 40, 20)
    for jour in range(100):
        Simulation(plante_list, herbivore_list, carnivore_list, jour)
        print(
            f"Jour {jour}: {len(plante_list)} plantes, "
            f"{len(herbivore_list)} herbivores, {len(carnivore_list)} carnivores"
        )


if __name__ == "__main__":
    main()
